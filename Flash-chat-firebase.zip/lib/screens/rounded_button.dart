import 'package:flutter/material.dart';
class RoundedButton extends StatelessWidget {
  final Color colorName;
  final String buttonName;
  final Function onPressBtn;
  RoundedButton(this.colorName,this.buttonName,this.onPressBtn);
  @override


  Widget build(BuildContext context) {
    return  Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Material(
        color: colorName,
        borderRadius: BorderRadius.all(Radius.circular(30.0)),
        elevation: 5.0,
        child: MaterialButton(
          onPressed: onPressBtn,
          minWidth: 200.0,
          height: 42.0,
          child: Text(
            buttonName,
          ),
        ),
      ),
    );
  }
}
