class Questions{
  String Qtext;
  bool Ans;
  Questions({String q,bool a}){
    Qtext = q;
    Ans = a;
  }
}