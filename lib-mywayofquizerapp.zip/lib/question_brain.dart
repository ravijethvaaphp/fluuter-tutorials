import 'Questions.dart';
class QuestionsBrain{
    int _QueNum = 0;

    List<Questions> _QuestionList = [
    new Questions(q:'You can lead a cow down stairs but not up stairs.',a:false),
    new Questions(q:'Approximately one quarter of human bones are in the feet.',a:true),
    new Questions(q:'A slug\'s blood is green.',a:true),

  ];
    bool nextQuestion(){
       bool isValid = false;
      if(_QueNum < _QuestionList.length -  1) {
        _QueNum++;
        isValid = true;
      }
      return isValid;

    }
    String getQuestionText() {
      return _QuestionList[_QueNum].Qtext;
    }
    bool getQuestionAns() {
      return _QuestionList[_QueNum].Ans;
    }
}