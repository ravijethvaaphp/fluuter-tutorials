class Story{
  String storyTitle;
  String choice1;
  String choice2;
  Story({this.storyTitle,this.choice1,this.choice2}){}
}
