import 'package:bmi_calculator/reusable_card.dart';
import 'package:flutter/material.dart';
import 'final_button.dart';
import 'constants.dart';

class ResultsPage extends StatelessWidget {
  final String BMI;
  final String BMIResult;
  final String BMIAnnotation;
  ResultsPage(@required this.BMI,@required this.BMIResult,@required this.BMIAnnotation);
  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          title: Text('BMI CALCULATOR'),
        ),
        body: Container(
          child: Column(
crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: EdgeInsets.all(15.0),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "Your Result",
                    style: kResultTitleTextStyle,
                  ),
                ),
              ),
              Expanded(
                flex: 5,
                child: ReusableCard(
                  colour: kActiveCardColour,
                  cardChild: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[

                        Text(BMIResult.toUpperCase(), style: kBMItTextTitle),
                        Text(BMI,style: kBMIMainResult,),
                        Text(
                         BMIAnnotation,
                          textAlign: TextAlign.center,
                          style: kBMIInstructTExt,)
                    ],
                  ),
                ),
              ),
              FinalButton(txt: "RE-CALCULATE", onPressed: (){
                Navigator.pop(context);
              } )
            ],
          ),
        ));
  }
}
