import 'package:flutter/material.dart';

const Color kActiveCardColour = Color(0xFF1D1E33);
//const Color ActiveCardColour = Colors.red;
const kBottomContainerHeight = 80.0;
const kBottomContainerColour = Colors.pink;
const kInactiveCardColour = Color(0xFF111328);
const kIconTextStyle = TextStyle(fontSize: 18.0, color: Color(0XFF8D8E98));
const kLargeLbl = TextStyle(fontSize: 50.0, fontWeight: FontWeight.w900);
const kLargeBtnTextStyle = TextStyle(
  fontSize: 25.00,
  fontWeight: FontWeight.bold
);
const kResultTitleTextStyle = TextStyle(
    fontSize: 50.00,
    fontWeight: FontWeight.bold
);
const kBMItTextTitle = TextStyle(
    fontSize: 20.00,
    color: Colors.greenAccent,
    fontWeight: FontWeight.bold
);
const kBMIMainResult = TextStyle(
    fontSize: 100.00,

    fontWeight: FontWeight.bold
);
const kBMIInstructTExt = TextStyle(
    fontSize: 20.00,

    fontWeight: FontWeight.normal
);
