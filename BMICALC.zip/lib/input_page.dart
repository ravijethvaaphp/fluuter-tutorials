import 'package:bmi_calculator/final_button.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'constants.dart';
import 'icon_content.dart';
import 'round_icon.dart';
import 'reusable_card.dart';
import 'results.dart';
import 'final_button.dart';
import 'calculator_brain.dart';
class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

enum GenderType { male, female }

class _InputPageState extends State<InputPage> {
  @override
  GenderType selectedGender;
  int height = 180;
  int weight = 60;
  int age = 32;

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI CALCULATOR'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Row(
              children: <Widget>[
                Expanded(
                  child: ReusableCard(
                    tapEvent: () {
                      setState(() {
                        selectedGender = selectedGender == GenderType.male
                            ? null
                            : GenderType.male;
                      });
                    },
                    colour: selectedGender == GenderType.male
                        ? kActiveCardColour
                        : kInactiveCardColour,
                    cardChild:
                        IconContent(label: 'MALE', icon: FontAwesomeIcons.mars),
                  ),
                ),
                Expanded(
                    child: ReusableCard(
                  tapEvent: () {
                    setState(() {
                      selectedGender = selectedGender == GenderType.female
                          ? null
                          : GenderType.female;
                    });
                  },
                  colour: selectedGender == GenderType.female
                      ? kActiveCardColour
                      : kInactiveCardColour,
                  cardChild: IconContent(
                      label: 'FEMALE', icon: FontAwesomeIcons.venus),
                )),
              ],
            ),
          ),
          Expanded(
            child: ReusableCard(
              colour: kActiveCardColour,
              cardChild: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'HEIGHT',
                    style: kIconTextStyle,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(height.toString(), style: kLargeLbl),
                      Text('cm', style: kIconTextStyle),
                    ],
                  ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: const Color(0xff804040),
                      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 15),
                      overlayShape: RoundSliderOverlayShape(overlayRadius: 20),
                      thumbColor: Color(0XFFEb1555),
                      overlayColor: Color(0X29Eb1555),
                    ),
                    child: Slider(
                      value: height.toDouble(),
                      min: 120,
                      max: 220,
                      onChanged: (double newHeight) {
                        setState(() {
                          height = newHeight.round();
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: Row(
              children: <Widget>[
                Expanded(
                  child: ReusableCard(
                    colour: kActiveCardColour,
                    cardChild: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'WEIGHT',
                          style: kIconTextStyle,
                        ),
                        Text(
                          weight.toString(),
                          style: kLargeLbl,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            RoundIconButton(
                              icon: FontAwesomeIcons.minus,
                              weightPressed: (){
                                setState(() {
                                  --weight;
                                });
                              },
                            ),
                            SizedBox(
                              width: 15.00,
                            ),
                            RoundIconButton(
                              icon: FontAwesomeIcons.plus,
                              weightPressed: (){
                                setState(() {
                                  ++weight;
                                });
                              },
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: ReusableCard(
                    colour: kActiveCardColour,
                    cardChild:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'AGE',
                          style: kIconTextStyle,
                        ),
                        Text(
                          age.toString(),
                          style: kLargeLbl,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            RoundIconButton(
                              icon: FontAwesomeIcons.minus,
                              weightPressed: (){
                                setState(() {
                                  --age;
                                });
                              },
                            ),
                            SizedBox(
                              width: 15.00,
                            ),
                            RoundIconButton(
                              icon: FontAwesomeIcons.plus,
                              weightPressed: (){
                                setState(() {
                                  ++age;
                                });
                              },
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          FinalButton(txt: "CALCULATE", onPressed: (){
            CalculatorBrain calc = new CalculatorBrain(height, weight);
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context)=> ResultsPage(calc.calculateBMI(), calc.getResult(),calc.getAnnotation())));
          } )
        ],
      ),
    );
  }
}


class ArgumentScreen{
  final int age;
  final int height;
  final int weight;

  ArgumentScreen(this.weight, this.height,this.age);
}
//margin: EdgeInsets.all(15),
//decoration: BoxDecoration(
//color: Color(0xFF1D1E33),
//borderRadius: BorderRadius.circular(10.0)
//),
//),
