import 'package:flutter/material.dart';
import 'constants.dart';


class FinalButton extends StatelessWidget {
  final String txt;
  final Function onPressed;
  FinalButton({@required this.txt, @required this.onPressed});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: double.infinity,
        height: kBottomContainerHeight,
        color: kBottomContainerColour,
        padding: EdgeInsets.only(bottom: 20.0),
        child: Center(
          child: (Text(
            txt,
            style: kLargeBtnTextStyle,
          )),
        ),
      ),
    );
  }
}




//() {
//Navigator.pushNamed(
//context,
//'/results',
//);
//}

//arguments: ArgumentScreen(
//weight,
//height,
//age
//),
