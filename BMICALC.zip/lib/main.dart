import 'package:flutter/material.dart';
import 'input_page.dart';
import 'results.dart';

void main() => runApp(BMICalculator());

class BMICalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
home:InputPage()
//      initialRoute: '/',
//      routes: {
//        // When navigating to the "/" route, build the FirstScreen widget.
//        '/': (context) => InputPage(),
//        // When navigating to the "/second" route, build the SecondScreen widget.
//        '/results': (context) => ResultsPage(),
//      },
    );
  }
}
